CREATE TABLE IF NOT EXISTS produk(
 id_produk SERIAL PRIMARY KEY,
 nama_produk VARCHAR (255),
 harga DECIMAL (10,2),
 stok INTEGER,
 id_kategori INTEGER REFERENCES kategori(id_kategori),
 id_supplier INTEGER REFERENCES supplier(id_supplier),
 barcode VARCHAR(50),
 create_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 update_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS kategori(
 id_kategori SERIAL PRIMARY KEY,
 nama_kategori VARCHAR(255),
 create_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 update_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS supplier(
 id_supplier SERIAL PRIMARY KEY,
 nama_supplier VARCHAR(255),
 alamat VARCHAR(255),
 telepon VARCHAR(20),
 create_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 update_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS pelanggan(
 id_pelanggan SERIAL PRIMARY KEY,
 nama_pelanggan VARCHAR(255),
 alamat VARCHAR(255),
 telepon VARCHAR(20),
 create_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 update_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS karyawan(
 id_karyawan SERIAL PRIMARY KEY,
 nama_karyawan VARCHAR(255),
 username VARCHAR(100),
 PASSWORD VARCHAR(255),
 create_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 update_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS penjualan(
 id_penjualan SERIAL PRIMARY KEY,
 id_karyawan INTEGER REFERENCES karyawan(id_karyawan),
 id_pelanggan INTEGER REFERENCES pelanggan(id_pelanggan),
 tanggal DATE,
 total_harga DECIMAL(10,2),
 create_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 update_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS detail_penjualan(
 id_detail_penjualan SERIAL PRIMARY KEY,
 id_penjualan INTEGER REFERENCES penjualan(id_penjualan),
 id_produk INTEGER REFERENCES produk(id_produk),
 jumlah INTEGER,
 harga_satuan DECIMAL(10,2),
 subtotal DECIMAL(10,2),
 create_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 update_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS retur_penjualan(
 id_retur_penjualan SERIAL PRIMARY KEY,
 id_karyawan INTEGER REFERENCES karyawan(id_karyawan),
 id_penjualan INTEGER REFERENCES penjualan(id_penjualan),
 tanggal_retur DATE,
 alasan VARCHAR(255),
 create_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 update_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS pembelian(
 id_pembelian SERIAL PRIMARY KEY,
 id_karyawan INTEGER REFERENCES karyawan(id_karyawan),
 id_supplier INTEGER REFERENCES pelanggan(id_supplier),
 tanggal DATE,
 total_harga DECIMAL(10,2),
 create_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 update_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS detail_pembelian(
 id_detail_pembelian SERIAL PRIMARY KEY,
 id_pembelian INTEGER REFERENCES penjualan(id_pembelian),
 id_produk INTEGER REFERENCES produk(id_produk),
 jumlah INTEGER,
 harga_satuan DECIMAL(10,2),
 subtotal DECIMAL(10,2),
 create_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 update_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS retur_pembelian(
 id_retur_pembelian SERIAL PRIMARY KEY,
 id_karyawan INTEGER REFERENCES karyawan(id_karyawan),
 id_pembelian INTEGER REFERENCES penjualan(id_pembelian),
 tanggal_retur DATE,
 alasan VARCHAR(255),
 create_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 update_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);